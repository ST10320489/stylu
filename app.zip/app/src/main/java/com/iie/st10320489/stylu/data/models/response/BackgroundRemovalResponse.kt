package com.iie.st10320489.stylu.data.models.response

data class BackgroundRemovalResponse(
    val success: Boolean,
    val imageUrl: String?,
    val error: String?
)