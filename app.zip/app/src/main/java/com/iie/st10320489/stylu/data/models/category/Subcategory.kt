package com.iie.st10320489.stylu.data.models.category

data class Subcategory(
    val subcategoryId: Int,
    val categoryId: Int,
    val name: String
)